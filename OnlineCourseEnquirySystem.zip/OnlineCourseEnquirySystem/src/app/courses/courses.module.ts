import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CourseListComponent } from './course-list/course-list.component';
import { ManageCoursesComponent } from './manage-courses/manage-courses.component';
import { RouterModule } from '@angular/router';


@NgModule({
  declarations: [CourseListComponent, ManageCoursesComponent],
  imports: [
    CommonModule,
    RouterModule
  ],
  exports:[CourseListComponent]
})
export class CoursesModule { }
