const root="http://localhost:5500";

export const ENDPOINTS={
    LOGIN:`${root}/authenticate`,
    REGISTER:`${root}/register`,
    //USERS:`${root}/allUsers`,
    //UPDATE_USER:`${root}/updateUser`,
    //DELETE_USER:`${root}/deleteUser`,
    //SUBJECT_BY_COURSE_ID:`${root}/subjectsbycourseid/{id}`,
    //ENQUIRY:`${root}/enquiry`,
    //QUERIES:`${root}/allQueries`,
    //UNRESOLVED_QUERIES:`${root}/unresolvedQueries`,
    //RESOLVED_QUERIES:`${root}/resolvedQueries`,
    COURSES:`${root}/courses`,
    //COURSE_BY_NAME:`${root}/course/{courseName}`,
    //ADD_COURSE:`${root}/addCourse`,
    //UPDATE_COURSE:`${root}/updateCourse`,
    //DELETE_COURSE:`${root}/deleteCourse`,
}