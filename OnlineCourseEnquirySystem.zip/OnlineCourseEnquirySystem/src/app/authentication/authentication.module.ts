import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { AdminComponent } from './admin/admin.component';
import { RepresentativeComponent } from './representative/representative.component';
import { FormsModule } from '@angular/forms';
import { ManageUsersComponent } from './manage-users/manage-users.component';
import { RouterModule } from '@angular/router';



@NgModule({
  declarations: [LoginComponent, AdminComponent, RepresentativeComponent, ManageUsersComponent],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule
  ],
  exports:[
    LoginComponent,
    AdminComponent,
    RepresentativeComponent
  ]
})
export class AuthenticationModule { }
