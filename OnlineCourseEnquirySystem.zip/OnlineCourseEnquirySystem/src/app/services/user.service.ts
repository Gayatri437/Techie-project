import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {ENDPOINTS} from '../endpoints/rest.endpoints';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }

  signIn(user)
  {
    return this.http.post(ENDPOINTS.LOGIN,user).toPromise();
  }

  signUp(user)
  {
    return this.http.post(ENDPOINTS.REGISTER,user).toPromise();
  }

}
