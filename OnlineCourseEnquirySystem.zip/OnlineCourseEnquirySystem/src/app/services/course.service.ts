import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {ENDPOINTS} from '../endpoints/rest.endpoints';

@Injectable({
  providedIn: 'root'
})
export class CourseService {

  constructor(private http:HttpClient) { }

  showCourses()
  {
    return this.http.get(ENDPOINTS.COURSES).toPromise();
  }
}
